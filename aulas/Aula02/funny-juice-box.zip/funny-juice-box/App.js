import { View, StyleSheet } from 'react-native';
import Box from './components/Box';

const App = () => (
  <View style={styles.container}>
    <Box size={50} color="blue" flex={1}></Box>
    <Box size={50} color="red" flex={2}></Box>
    <Box size={50} color="green" flex={3}></Box>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'space-evenly',
    alingItens: 'stratch'
  },
});

export default App;
