import {View} from 'react-native'

const Box =(props) => {
  const boxStyle={
    height: props.size,
    width: props.size,
  // flex: props.flex,
    backgroundColor: props.color,
  };
  
  return(
    <View style={boxStyle}></View>


  );
};

export default Box;